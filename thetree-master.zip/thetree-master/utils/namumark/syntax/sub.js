module.exports = {
    openStr: `,,`,
    closeStr: `,,`,
    format: content => `<sub>${content}</sub>`
}