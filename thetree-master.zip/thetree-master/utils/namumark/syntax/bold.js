module.exports = {
    openStr: `'''`,
    closeStr: `'''`,
    format: content => `<strong>${content}</strong>`
}