module.exports = {
    openStr: `''`,
    closeStr: `''`,
    format: content => `<em>${content}</em>`
}