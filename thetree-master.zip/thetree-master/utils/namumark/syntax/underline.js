module.exports = {
    openStr: `__`,
    closeStr: `__`,
    format: content => `<u>${content}</u>`
}