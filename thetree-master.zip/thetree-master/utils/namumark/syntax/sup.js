module.exports = {
    openStr: `^^`,
    closeStr: `^^`,
    format: content => `<sup>${content}</sup>`
}