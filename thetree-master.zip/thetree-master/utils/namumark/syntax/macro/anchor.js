module.exports = str => {
    return `<a id="${str}"></a>`;
}