module.exports = {
    aliases: ['목차'],
    allowThread: true,
    format() {
        return '<[tocPos]>';
    }
}