module.exports = _ => {
    return '<br>';
}