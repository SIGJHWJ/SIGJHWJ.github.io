module.exports = {
    allowThread: true,
    format() {
        return '<div class="wiki-clearfix"></div>';
    }
}