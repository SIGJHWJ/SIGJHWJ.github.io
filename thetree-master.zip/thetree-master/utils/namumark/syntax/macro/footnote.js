module.exports = {
    aliases: ['각주'],
    allowThread: true,
    format() {
        return '<[footnotePos]>';
    }
}