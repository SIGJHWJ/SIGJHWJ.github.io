module.exports = {
    openStr: `~~`,
    closeStr: `~~`,
    format: content => `<del>${content}</del>`
}